﻿namespace BasicInternetDownloadManager
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Threading;

    internal class MultiBlockFileController
    {
        private int number;
        private double precent;
        private State state;
        private string link;
        private long fileSize;


        private int completed = 0;

        internal delegate void UpdatePBInfo(FileDownloader fd,bool isLastPacket);
        private List<FileDownloader> blocks = new List<FileDownloader>();
        public int Number { get => number;}
        public double Precent { get => precent; }
        internal State State { get => state; }
        public string Link { get => link; }

        internal MultiBlockFileController(
            int number,
            string link
            )
        {
            this.number = number;
            this.link = link;

            long blockSize = 0;

            while(this.fileSize == 0)
            {
                this.fileSize = QueryFileSize();
                Thread.Sleep(1000);
            }

            blockSize = (long)Math.Floor((((double)this.fileSize) / ((double)Constants.ConnectionPerTask)));

            for(int i = 0;i< Constants.ConnectionPerTask - 1; i++)
            {
                FileDownloader fd = new FileDownloader(i+1, this.link, blockSize*i, blockSize *(i+1), blockSize, new UpdatePBInfo(UpdateP),this.number);
                this.blocks.Add(fd);
            }

            long lastBlockSize = this.fileSize - (blocks.Count*blockSize);

            FileDownloader lastBlock = new FileDownloader(blocks.Count+1, this.link, blockSize * blocks.Count, this.fileSize, lastBlockSize, new UpdatePBInfo(UpdateP),this.number);
            this.blocks.Add(lastBlock);

            Start();
        }

        internal void Start()
        {
            foreach(FileDownloader b in blocks)
            {
                b.Start();
            }

            this.state = State.CONNECTING;
        }

        internal void Stop()
        {
            foreach (FileDownloader b in blocks)
            {
                b.Stop();
            }

            this.state = State.STOPPED;
        }


        internal void Cancel()
        {
            Clear();
        }

        private void Clear()
        {
            foreach (FileDownloader b in blocks)
            {
                b.Cencel();
            }

            this.state = State.STOPPED;
        }

        public object obj = new object();
        private int ticker;
        private void UpdateP(FileDownloader fs,bool isLastPacket)
        {
            lock (obj)
            {
                if ((Environment.TickCount - ticker >=1000) || isLastPacket)
                {
                    ticker = Environment.TickCount;

                    if (isLastPacket)
                    {
                        completed++;
                    }
                    //lock (obj)
                    //{
                    double p = 0;
                    foreach (FileDownloader b in blocks)
                    {
                        p += b.GetDownloadedFileSize();
                    }

                    this.precent = (p / ((double)this.fileSize)) * (double)100;

                    if (completed == Constants.ConnectionPerTask)
                    {
                        this.state = State.REBUILD;
                        new UpdateListView().UpdateLV(this);
                        Rebuild();
                        this.state = State.COMPLETE;

                        foreach (FileDownloader b in blocks)
                        {
                            b.Clear();
                        }
                    }
                    else
                    {
                        this.state = State.DOWNLOADING;
                    }

                    new UpdateListView().UpdateLV(this);
                }
            }

        }

        private bool Rebuild()
        {
            bool res = false;

            //try
            //{
                FileStream fs = new FileStream(Constants.DownloadFolder + "\\" + GetFileNameFromLink(), FileMode.Create);

                foreach(FileDownloader b in blocks)
                {
                    byte[] ar = b.GetBlockBytes();
                    fs.Write(ar, 0, ar.Length);
                }

                fs.Close();
                res = true;
            //}
            //catch { }
            return res;
        }

        private long QueryFileSize()
        {
            long res = 0;

            try
            {
                WebRequest wTX = WebRequest.Create(this.link);
                wTX.Credentials = GetCredential();
                wTX.PreAuthenticate = true;

               
                HttpWebResponse httpWebRespone = (HttpWebResponse)wTX.GetResponse();

                if (httpWebRespone.StatusCode == HttpStatusCode.OK)
                {
                    res = httpWebRespone.ContentLength;
                }

                httpWebRespone.Close();
            }
            catch { }
            return res;
        }

        private CredentialCache GetCredential()
        {
            System.Net.CredentialCache credentialCache = new System.Net.CredentialCache();

            credentialCache.Add(
                new System.Uri(this.link),
                "Basic",
                new System.Net.NetworkCredential("admin", "123456")
            );

            return credentialCache;
        }

        private string GetFileNameFromLink()
        {
            string res = string.Empty;

            try
            {
                Uri url = new Uri(this.link);
                res = this.number.ToString() + "_" + url.Segments[url.Segments.Length - 1];
            }
            catch { }

            return res;
        }
    }


}
