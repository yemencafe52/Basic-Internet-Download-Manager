﻿namespace BasicInternetDownloadManager
{
    using System;
    class Constants
    {
        private static string tempFolder = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\BIDMTemp";
        private static string downloadFolder = System.IO.Directory.GetCurrentDirectory() + "\\Downloads";
        private static int connectionPerTask = 32; 

        internal static int ConnectionPerTask
        {
            get
            {
                return connectionPerTask;
            }
        }

        internal static string TempFolder
        {
            get
            {
                return tempFolder;
            }
        }
        internal static string DownloadFolder
        {
            get
            {
                return downloadFolder;
            }
        }
    }
}
