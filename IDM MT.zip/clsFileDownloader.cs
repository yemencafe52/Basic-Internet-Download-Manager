﻿namespace BasicInternetDownloadManager
{
    using System;
    using System.Text;
    using System.Threading.Tasks;
    using System.Security.Cryptography;
    using System.IO;
    using System.Net;
    using System.Threading;
    internal enum State : byte
    {
        STOPPED = 0,
        CONNECTING,
        QUERY,
        DOWNLOADING,
        COMPLETE,
        DISCONNECTED,
        REBUILD
    }
    internal class FileDownloader
    {
        private int number;
        private string link;
        private double precent;
        private State state;
        //------------------
        private bool isRunning;
        private string filePath;

        private long fromPo;
        private long toPo;
        private long blockSize;

        private MultiBlockFileController.UpdatePBInfo UpdatePBInfo;

        public int Number { get => number; }
        public string Link { get => link; }
        public double Precent { get => precent; }
        internal State State { get => state; }
        public long FromPo { get => fromPo; }
        public long ToPo { get => toPo; }
        public long BlockSize { get => blockSize;}
        private int tid;

        internal FileDownloader(
            int number
            , 
            string link
            ,
            long fromPo
            ,
            long toPo
            ,
            long blockSize
            ,
            MultiBlockFileController.UpdatePBInfo UpdatePBInfo
            ,
            int tid
            )
        {
            this.number = number;
            this.link = link;
            this.fromPo = fromPo;
            this.toPo = toPo;
            this.blockSize = blockSize;
            this.UpdatePBInfo = UpdatePBInfo;
            this.tid = tid;
            GetTempFilePath();
        }
        int counter;
        internal async void Start()
        {
           
            this.isRunning = true;

            while (
                (this.isRunning)
                &&
                (this.state != State.COMPLETE)
                )
            {
                //try
                //{
                   await Task.Run(() =>
                 {
                        if (this.fromPo + GetDownloadedFileSize() >= this.toPo)
                        {
                            this.state = State.COMPLETE;
                            this.isRunning = false;
                            this.UpdatePBInfo(this,true);
                            return;
                        }

                        this.state = State.CONNECTING;

                        HttpWebRequest wTX = (HttpWebRequest)WebRequest.Create(this.link);
                        wTX.Credentials = GetCredential();
                        wTX.PreAuthenticate = true;

                        wTX.AddRange(this.fromPo+GetDownloadedFileSize(),this.toPo);

                        bool isLastPacket = false;
                        HttpWebResponse wRX = (HttpWebResponse)wTX.GetResponse();

                        if ((((HttpWebResponse)wRX).StatusCode == HttpStatusCode.OK) || (((HttpWebResponse)wRX).StatusCode) == HttpStatusCode.PartialContent)
                        {
                            Stream s = wRX.GetResponseStream();
                            long bufferSize = 1024 * 1024 * 8;
                            
                         
                         long currentBufferSize = this.toPo - (this.fromPo + this.GetDownloadedFileSize());

                         if (!(currentBufferSize > bufferSize))
                         {
                             bufferSize = currentBufferSize;
                         }
                         byte[] buffer = new byte[bufferSize];

                         int len = 0;

                            this.state = State.DOWNLOADING;
                            while (
                            ((len = s.Read(buffer, 0, buffer.Length)) > 0)
                            &&
                            (this.isRunning)
                            )
                            {
                              //  lock (obj)
                                {
                                    
                                    using (FileStream fs = new FileStream(this.filePath, FileMode.Append))
                                    {
                                        fs.Write(buffer, 0, len);
                                        this.precent = ((double)fs.Length / (double)this.blockSize) * (double)100;

                                        if (fs.Length >= this.blockSize)
                                        {
                                            isLastPacket = true;
                                            this.state = State.COMPLETE;
                                            this.isRunning = false;
                                        }

                                     currentBufferSize = this.toPo - (this.fromPo + this.GetDownloadedFileSize());
                                     if (currentBufferSize > 0)
                                     {
                                         if (!(currentBufferSize > bufferSize))
                                         {
                                             bufferSize = currentBufferSize;
                                             buffer = new byte[bufferSize];
                                         }
                                     }

                                     fs.Close();

                                     
                                        this.UpdatePBInfo(this,isLastPacket);
                                    }
                                }
                            }

                            s.Close();
                            
                        }
                    });
                //}

                //catch
                //{
                //    return;
                //    //this.state = State.DISCONNECTED;
                //    //Thread.Sleep(1000);
                //}
            }
        }
        internal void Stop()
        {
            try
            {
                this.isRunning = false;
                this.state = State.STOPPED;
            }
            catch { }
        }
        internal void Cencel()
        {
            Stop();

            try
            {
                this.isRunning = false;
                this.state = State.STOPPED;
                File.Delete(this.filePath);
            }
            catch { }
        }

        private CredentialCache GetCredential()
        {
            System.Net.CredentialCache credentialCache = new System.Net.CredentialCache();

            credentialCache.Add(
                new System.Uri(this.link),
                "Basic",
                new System.Net.NetworkCredential("admin", "123456")
            );

            return credentialCache;
        }

        private static object obj = new object();
        public long GetDownloadedFileSize()
        {
            //lock(obj)
            {
                long res = 0;

                try
                {
                    if (File.Exists(this.filePath))
                    {
                        res = new FileInfo(this.filePath).Length;
                    }
                }
                catch { }
                return res;
            }
        }
        private string GetTempFilePath()
        {
            string res = string.Empty;

            try
            {
                if (this.filePath is null)
                {
                    if (!(System.IO.Directory.Exists(Constants.TempFolder + "\\" + GetHashTempFileName())))
                    {
                        System.IO.Directory.CreateDirectory(Constants.TempFolder + "\\" + GetHashTempFileName());
                    }

                    this.filePath = Constants.TempFolder + "\\" + GetHashTempFileName() + $"\\{this.number}";

                    FileStream fs = new FileStream(this.filePath, FileMode.OpenOrCreate);
                    fs.Close();
                }

                res = this.filePath;

            }

            catch { }
            return res;
        }
        private string GetHashTempFileName()
        {
            string res = string.Empty;
            using (MD5 md5 = MD5CryptoServiceProvider.Create())
            {
                byte[] ar = md5.ComputeHash(Encoding.UTF8.GetBytes(this.link + tid)); ;

                StringBuilder sb = new StringBuilder();
                foreach(byte b in ar)
                {
                    sb.Append(b.ToString("x2"));
                }

                res = sb.ToString();
            }
            return res;
        }


        internal byte[] GetBlockBytes()
        {
           // lock (obj)
            {
                //while (true)
                //{
                //    try
                //    {
                        return File.ReadAllBytes(this.filePath);
                //    }
                //    catch { }
                //}
            }
        }

        internal void Clear()
        {
            try
            {
                if (File.Exists(this.filePath))
                {
                    File.Delete(this.filePath);
                }
            }
            catch { }
        }
    }
}
