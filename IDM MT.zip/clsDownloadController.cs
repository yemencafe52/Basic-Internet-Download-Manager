﻿namespace BasicInternetDownloadManager
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    internal class DownloadController
    {
        private static List<MultiBlockFileController> files;
        private static int fileNumber = 0;
        //================================
        private static object obj = new object();

        internal DownloadController()
        {
            if (files is null)
            {
                files = new List<MultiBlockFileController>();
            }
        }
        internal void Add(string link)
        {
            files.Add(new MultiBlockFileController(++fileNumber, link));
            //files[files.Count - 1].Start();
            new UpdateListView().UpdateLV((files[files.Count - 1]));
        }
        internal void Stop(int number)
        {
            MultiBlockFileController fd = files.Find(p => p.Number == number);

            if(!(fd is null))
            {
                fd.Stop();
            }

            new UpdateListView().UpdateLV(fd);
        }
        internal void Resume(int number)
        {
            MultiBlockFileController fd = files.Find(p => p.Number == number);

            if (!(fd is null))
            {
                fd.Start();
            }

            new UpdateListView().UpdateLV(fd);
        }
        internal void Cancel(int number)
        {
            MultiBlockFileController fd = files.Find(p => p.Number == number);

            if (!(fd is null))
            {
                fd.Cancel();
            }

            files.Remove(fd);
        }
    }


    internal class UpdateListView
    {
        internal delegate void UpdateViewDlg(MultiBlockFileController fd);
        internal static event UpdateViewDlg UpdateView;
        internal void UpdateLV(MultiBlockFileController m)
        {
            UpdateView(m);
        }
    }
}
